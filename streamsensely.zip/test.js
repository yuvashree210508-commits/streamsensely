const express = require('express');
const router = express.Router();
const { protect } = require('../middleware/auth');
const TestResult = require('../models/TestResult');

// ──────────────────────────────────────
// AI Career Suggestion Engine
// ──────────────────────────────────────
const careerData = {
  science: {
    label: 'Science Stream',
    emoji: '🔬',
    description: 'Best for students who love logical thinking, problem-solving, and exploring how the world works.',
    subFields: {
      'AI & Machine Learning': {
        emoji: '🤖',
        description: 'Build intelligent systems that learn from data.',
        courses: [
          { name: 'B.Tech Computer Science (AI/ML)', duration: '4 years', type: 'Degree' },
          { name: 'BCA with AI Specialization', duration: '3 years', type: 'Degree' },
          { name: 'Diploma in AI & Data Science', duration: '1-2 years', type: 'Diploma' }
        ],
        roadmap: {
          school: ['Focus on Maths & Computer Science', 'Learn Python basics', 'Join coding clubs', 'Participate in science fairs'],
          college: ['B.Tech CSE or BCA', 'Learn ML frameworks (TensorFlow, PyTorch)', 'Work on mini-projects', 'Intern at tech companies'],
          advanced: ['Masters in AI (IIT, NIT, or abroad)', 'Research publications', 'Work at Google, Microsoft, ISRO', 'Start AI startup']
        },
        skills: ['Python', 'Mathematics', 'Statistics', 'Machine Learning', 'Deep Learning', 'Data Analysis'],
        avgSalary: '₹8-40 LPA',
        jobRoles: ['AI Engineer', 'Data Scientist', 'ML Engineer', 'Research Scientist']
      },
      'Robotics & Automation': {
        emoji: '⚙️',
        description: 'Design and build intelligent machines of the future.',
        courses: [
          { name: 'B.Tech Mechanical/Electronics Engineering', duration: '4 years', type: 'Degree' },
          { name: 'B.Tech Robotics Engineering', duration: '4 years', type: 'Degree' },
          { name: 'Diploma in Industrial Automation', duration: '2 years', type: 'Diploma' }
        ],
        roadmap: {
          school: ['Maths & Physics focus', 'Build simple Arduino projects', 'Join robotics clubs', 'Compete in science olympiads'],
          college: ['B.Tech in Robotics/Mechanical/ECE', 'Learn ROS (Robot OS)', 'Internship in manufacturing', 'Build robotic prototypes'],
          advanced: ['M.Tech Robotics', 'Work at ISRO, DRDO, Tesla', 'Patent your innovations', 'Research in humanoid robots']
        },
        skills: ['Electronics', 'Programming', 'CAD Design', 'Physics', 'Problem Solving', 'Arduino/Raspberry Pi'],
        avgSalary: '₹6-30 LPA',
        jobRoles: ['Robotics Engineer', 'Automation Engineer', 'Research & Development', 'Product Engineer']
      },
      'Medicine & Healthcare': {
        emoji: '🏥',
        description: 'Save lives and serve humanity through medical science.',
        courses: [
          { name: 'MBBS', duration: '5.5 years', type: 'Degree' },
          { name: 'BAMS / BHMS', duration: '5.5 years', type: 'Degree' },
          { name: 'B.Sc Nursing', duration: '4 years', type: 'Degree' }
        ],
        roadmap: {
          school: ['Biology + Chemistry focus', 'NEET preparation', 'Volunteer at hospitals', 'Attend medical workshops'],
          college: ['MBBS or BDS', 'Clinical rotations', 'Research publications', 'Medical internship'],
          advanced: ['MD/MS specialization', 'Work at AIIMS, Apollo', 'Medical research', 'Start own clinic']
        },
        skills: ['Biology', 'Chemistry', 'Patient Care', 'Critical Thinking', 'Communication', 'Empathy'],
        avgSalary: '₹5-50 LPA',
        jobRoles: ['Doctor', 'Surgeon', 'Researcher', 'Medical Officer']
      },
      'Data Science': {
        emoji: '📊',
        description: 'Turn raw data into powerful business insights.',
        courses: [
          { name: 'B.Tech CSE (Data Science)', duration: '4 years', type: 'Degree' },
          { name: 'B.Sc Data Science', duration: '3 years', type: 'Degree' },
          { name: 'Diploma in Data Analytics', duration: '1 year', type: 'Diploma' }
        ],
        roadmap: {
          school: ['Strong Mathematics', 'Learn Excel and basics', 'Statistics knowledge', 'Competitive coding'],
          college: ['BSc/BTech Data Science', 'Kaggle competitions', 'SQL & Python proficiency', 'Industry internships'],
          advanced: ['MS in Data Science', 'Work at top MNCs', 'Business analytics roles', 'Data strategy leadership']
        },
        skills: ['Statistics', 'Python/R', 'SQL', 'Data Visualization', 'Business Acumen', 'Machine Learning'],
        avgSalary: '₹7-35 LPA',
        jobRoles: ['Data Analyst', 'Data Scientist', 'Business Intelligence', 'Analytics Engineer']
      }
    }
  },
  commerce: {
    label: 'Commerce Stream',
    emoji: '💼',
    description: 'Perfect for students interested in business, finance, economics, and entrepreneurship.',
    subFields: {
      'Chartered Accountancy (CA)': {
        emoji: '📋',
        description: 'Become a financial expert and trusted business advisor.',
        courses: [
          { name: 'CA Foundation + Intermediate + Final', duration: '5 years', type: 'Professional' },
          { name: 'B.Com (Hons)', duration: '3 years', type: 'Degree' },
          { name: 'BBA Finance', duration: '3 years', type: 'Degree' }
        ],
        roadmap: {
          school: ['Commerce with Accountancy', 'Maths is important', 'ICAI CA Foundation prep', 'Current affairs knowledge'],
          college: ['Register for CA Foundation', 'Clear Intermediate exams', 'Article-ship training', 'CA Final examination'],
          advanced: ['Big 4 firms (Deloitte, EY, KPMG)', 'CFO roles', 'Start own CA firm', 'International CPA certification']
        },
        skills: ['Accounting', 'Taxation', 'Financial Analysis', 'Auditing', 'Excel', 'Communication'],
        avgSalary: '₹7-50 LPA',
        jobRoles: ['Chartered Accountant', 'Tax Consultant', 'CFO', 'Financial Advisor']
      },
      'Business Management (MBA)': {
        emoji: '🏢',
        description: 'Lead organizations and drive business growth.',
        courses: [
          { name: 'BBA (Bachelor of Business Admin)', duration: '3 years', type: 'Degree' },
          { name: 'B.Com + MBA', duration: '5 years', type: 'Degree' },
          { name: 'Integrated MBA', duration: '5 years', type: 'Degree' }
        ],
        roadmap: {
          school: ['Commerce stream', 'Leadership in school events', 'Public speaking skills', 'Entrepreneurship clubs'],
          college: ['BBA / B.Com', 'CAT/MAT/XAT preparation', 'Internships in companies', 'Case study competitions'],
          advanced: ['MBA from IIM/top B-school', 'Corporate roles', 'Start your own business', 'C-Suite leadership']
        },
        skills: ['Leadership', 'Communication', 'Strategic Thinking', 'Finance', 'Marketing', 'Team Management'],
        avgSalary: '₹8-60 LPA',
        jobRoles: ['Business Manager', 'Marketing Manager', 'Entrepreneur', 'Consultant']
      }
    }
  },
  arts: {
    label: 'Arts & Humanities',
    emoji: '🎨',
    description: 'Ideal for creative, expressive students who want to shape culture and society.',
    subFields: {
      'Design & Animation': {
        emoji: '✏️',
        description: 'Create visual experiences that captivate and inspire.',
        courses: [
          { name: 'B.Des (Bachelor of Design)', duration: '4 years', type: 'Degree' },
          { name: 'B.Sc Animation & VFX', duration: '3 years', type: 'Degree' },
          { name: 'Diploma in Graphic Design', duration: '1 year', type: 'Diploma' }
        ],
        roadmap: {
          school: ['Arts focus', 'Learn Canva/Photoshop', 'Build portfolio', 'Participate in design competitions'],
          college: ['B.Des or B.Sc Animation', 'Master Adobe suite', 'Freelance projects', 'Internship at studios'],
          advanced: ['Work at top design firms', 'UI/UX specialization', 'Game design or VFX', 'Start design agency']
        },
        skills: ['Creativity', 'Adobe Tools', 'Typography', 'Color Theory', 'UI/UX', '3D Modeling'],
        avgSalary: '₹4-25 LPA',
        jobRoles: ['UI/UX Designer', 'Graphic Designer', 'Animator', 'Art Director']
      },
      'Journalism & Media': {
        emoji: '📰',
        description: 'Inform the world and shape public discourse through powerful storytelling.',
        courses: [
          { name: 'BA Journalism & Mass Communication', duration: '3 years', type: 'Degree' },
          { name: 'B.Sc Media Studies', duration: '3 years', type: 'Degree' },
          { name: 'Diploma in Digital Media', duration: '1 year', type: 'Diploma' }
        ],
        roadmap: {
          school: ['Good in languages', 'School newspaper/blog', 'Video content creation', 'Debate & elocution'],
          college: ['BA MJMC', 'Internship at news channels', 'Build social media presence', 'Documentary projects'],
          advanced: ['Work at The Hindu, NDTV', 'Foreign correspondency', 'Media entrepreneurship', 'Award-winning journalism']
        },
        skills: ['Writing', 'Communication', 'Research', 'Video Editing', 'Social Media', 'Critical Thinking'],
        avgSalary: '₹3-20 LPA',
        jobRoles: ['Journalist', 'Content Creator', 'PR Manager', 'News Anchor']
      }
    }
  },
  vocational: {
    label: 'Vocational / Skill-Based',
    emoji: '🔧',
    description: 'Hands-on learning for practical skills with quick job entry.',
    subFields: {
      'ITI & Polytechnic': {
        emoji: '🏭',
        description: 'Master technical skills for immediate employment.',
        courses: [
          { name: 'Polytechnic Diploma (Engineering)', duration: '3 years', type: 'Diploma' },
          { name: 'ITI (various trades)', duration: '1-2 years', type: 'Certificate' },
          { name: 'B.Tech (Lateral Entry after Diploma)', duration: '3 years', type: 'Degree' }
        ],
        roadmap: {
          school: ['Science/Maths basics', 'Practical skills focus', 'Technical drawing', 'Workshop training'],
          college: ['ITI or Polytechnic', 'TNPSC/UPSC technical exams', 'Industry apprenticeship', 'Lateral entry B.Tech'],
          advanced: ['Government jobs (TANGEDCO, TNEB)', 'Private sector roles', 'Entrepreneur in trades', 'B.Tech completion']
        },
        skills: ['Technical Skills', 'Hands-on Work', 'Safety Protocols', 'Basic Electronics', 'Problem Solving'],
        avgSalary: '₹2-12 LPA',
        jobRoles: ['Technician', 'Electrician', 'Mechanic', 'Factory Supervisor']
      }
    }
  }
};

// ──────────────────────────────────────
// AI Scoring Function
// ──────────────────────────────────────
function analyzeAnswers(answers) {
  const scores = { science: 0, commerce: 0, arts: 0, vocational: 0 };
  
  answers.forEach(a => {
    if (a.category) scores[a.category] = (scores[a.category] || 0) + 1;
  });

  // Determine stream
  const sorted = Object.entries(scores).sort((a, b) => b[1] - a[1]);
  const topStream = sorted[0][0];
  const total = Object.values(scores).reduce((a, b) => a + b, 0);
  const confidenceScore = total > 0 ? Math.round((sorted[0][1] / total) * 100) : 60;

  const streamData = careerData[topStream];
  const subFields = Object.keys(streamData.subFields).slice(0, 3);
  const primaryCareer = subFields[0];
  const primaryData = streamData.subFields[primaryCareer];

  return {
    scores,
    suggestedStream: streamData.label,
    streamKey: topStream,
    subFields,
    primaryCareer,
    roadmap: primaryData.roadmap,
    skillsRequired: primaryData.skills,
    courses: primaryData.courses,
    confidenceScore
  };
}

// GET all questions
router.get('/questions', (req, res) => {
  const questions = [
    { id: 1, text: 'Which subject do you enjoy the most?', category: 'interest', options: [{ text: 'Mathematics & Physics', category: 'science' }, { text: 'Accounts & Economics', category: 'commerce' }, { text: 'Drawing & Languages', category: 'arts' }, { text: 'Practical / Workshop work', category: 'vocational' }] },
    { id: 2, text: 'What would you prefer to do on weekends?', category: 'habit', options: [{ text: 'Coding or Science experiments', category: 'science' }, { text: 'Starting a small business / selling things', category: 'commerce' }, { text: 'Drawing, painting, or writing stories', category: 'arts' }, { text: 'Fixing gadgets or building things', category: 'vocational' }] },
    { id: 3, text: 'Which TV show would you binge-watch?', category: 'interest', options: [{ text: 'Tech documentaries or Science shows', category: 'science' }, { text: 'Shark Tank or business shows', category: 'commerce' }, { text: 'Movies, anime or creative shows', category: 'arts' }, { text: 'How-it-works or home improvement', category: 'vocational' }] },
    { id: 4, text: 'What kind of problems do you love solving?', category: 'aptitude', options: [{ text: 'Logical puzzles and equations', category: 'science' }, { text: 'Financial planning or business challenges', category: 'commerce' }, { text: 'Creative challenges and design problems', category: 'arts' }, { text: 'Technical / mechanical problems', category: 'vocational' }] },
    { id: 5, text: 'Which career sounds most exciting to you?', category: 'ambition', options: [{ text: 'AI Engineer at Google or ISRO Scientist', category: 'science' }, { text: 'CEO or Chartered Accountant', category: 'commerce' }, { text: 'Graphic Designer or Film Director', category: 'arts' }, { text: 'Skilled Technician or Factory Manager', category: 'vocational' }] },
    { id: 6, text: 'How do you prefer to work?', category: 'workstyle', options: [{ text: 'Analyzing data and solving complex problems', category: 'science' }, { text: 'Managing people and money', category: 'commerce' }, { text: 'Creating and expressing ideas', category: 'arts' }, { text: 'Working with hands and tools', category: 'vocational' }] },
    { id: 7, text: 'Your dream project would be...', category: 'ambition', options: [{ text: 'Building a robot or AI app', category: 'science' }, { text: 'Launching a startup or investment plan', category: 'commerce' }, { text: 'Making a short film or designing a logo', category: 'arts' }, { text: 'Building an electrical system or machine', category: 'vocational' }] },
    { id: 8, text: 'Which icon matches you best?', category: 'personality', options: [{ text: '🔬 The Scientist - curious and analytical', category: 'science' }, { text: '💰 The Entrepreneur - smart and ambitious', category: 'commerce' }, { text: '🎨 The Creative - imaginative and expressive', category: 'arts' }, { text: '🔧 The Builder - practical and skilled', category: 'vocational' }] },
    { id: 9, text: 'Which subject do you score the highest in?', category: 'academic', options: [{ text: 'Maths or Science subjects', category: 'science' }, { text: 'Accountancy or Economics', category: 'commerce' }, { text: 'Languages or Social Science', category: 'arts' }, { text: 'Practical / Technical subjects', category: 'vocational' }] },
    { id: 10, text: 'Where do you see yourself in 10 years?', category: 'vision', options: [{ text: 'Leading a tech team or doing research', category: 'science' }, { text: 'Running a company or managing finances', category: 'commerce' }, { text: 'Working in media, arts, or design industry', category: 'arts' }, { text: 'Running my own workshop or trade business', category: 'vocational' }] }
  ];
  res.json({ questions });
});

// POST submit test
router.post('/submit', protect, async (req, res) => {
  try {
    const { answers } = req.body;
    if (!answers || answers.length < 5) return res.status(400).json({ message: 'Please answer at least 5 questions' });

    const analysis = analyzeAnswers(answers);
    const result = await TestResult.create({ userId: req.user._id, answers, ...analysis });
    res.json({ result, careerDetails: careerData[analysis.streamKey] });
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
});

// GET career data
router.get('/career-data/:streamKey', (req, res) => {
  const data = careerData[req.params.streamKey];
  if (!data) return res.status(404).json({ message: 'Stream not found' });
  res.json(data);
});

module.exports = router;
module.exports.careerData = careerData;
