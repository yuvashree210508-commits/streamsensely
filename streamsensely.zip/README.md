# 🎓 StreamSensely — AI Career Guidance for Students

> Helping students in Tamil Nadu (and across India) discover their ideal career path after 10th Standard using AI-powered assessments.

---

## 📁 Folder Structure

```
streamsensely/
├── frontend/
│   └── index.html          ← Complete frontend (all 5 pages in one file)
├── backend/
│   ├── server.js            ← Express server entry point
│   ├── .env.example         ← Environment variable template
│   ├── package.json
│   ├── middleware/
│   │   └── auth.js          ← JWT authentication middleware
│   ├── models/
│   │   ├── User.js          ← User schema (MongoDB)
│   │   └── TestResult.js    ← Career test results schema
│   └── routes/
│       ├── auth.js          ← /api/auth (login, signup, me)
│       ├── test.js          ← /api/test (questions, submit + AI engine)
│       ├── career.js        ← /api/career (roadmaps)
│       └── dashboard.js     ← /api/dashboard (history, stats)
└── README.md
```

---

## 🚀 How to Run the Project

### Prerequisites
- Node.js v18+ → https://nodejs.org
- MongoDB (local) → https://www.mongodb.com/try/download/community
  OR use MongoDB Atlas (free cloud): https://cloud.mongodb.com

---

### Step 1 — Set up the Backend

```bash
cd streamsensely/backend

# Install dependencies
npm install

# Create your .env file
cp .env.example .env
# Edit .env and set your MONGO_URI if using Atlas
```

**Edit `.env`:**
```env
PORT=5000
MONGO_URI=mongodb://localhost:27017/streamsensely
JWT_SECRET=your_super_secret_key_here
CLIENT_URL=http://localhost:3000
NODE_ENV=development
```

**Start the backend:**
```bash
# Development (auto-restart on changes)
npm run dev

# Production
npm start
```

You should see:
```
✅ MongoDB Connected
🚀 StreamSensely server running on port 5000
```

---

### Step 2 — Open the Frontend

The frontend is a single HTML file — no build step needed!

**Option A — Just open in browser:**
```
Open streamsensely/frontend/index.html directly in Chrome/Firefox
```

**Option B — Serve with a local server (recommended):**
```bash
# Using npx (no install needed)
cd streamsensely/frontend
npx serve .

# Or using Python
python -m http.server 3000
```

Then visit: **http://localhost:3000**

---

## 🌐 Deploy to Production

### Free Hosting Options:

**Frontend (index.html):**
- **Netlify** → Drag & drop the `frontend` folder at netlify.app
- **Vercel** → `vercel deploy` from frontend folder
- **GitHub Pages** → Push to repo, enable Pages

**Backend (Node.js + Express):**
- **Render.com** → Free Node.js hosting (connect GitHub repo)
- **Railway.app** → Very easy, free tier available
- **Cyclic.sh** → Free Node.js hosting

**Database:**
- **MongoDB Atlas** → Free 512MB cluster at cloud.mongodb.com
  - Create account → New Project → Free Cluster → Get connection string
  - Update MONGO_URI in your .env

---

## 📡 API Reference

### Auth Endpoints
| Method | Path | Description |
|--------|------|-------------|
| POST | /api/auth/signup | Create new account |
| POST | /api/auth/login | Login and get JWT token |
| GET | /api/auth/me | Get current user (requires token) |

### Test Endpoints
| Method | Path | Description |
|--------|------|-------------|
| GET | /api/test/questions | Get all 10 career questions |
| POST | /api/test/submit | Submit answers, get AI result (requires auth) |
| GET | /api/test/career-data/:key | Get detailed stream data |

Keys: `science`, `commerce`, `arts`, `vocational`

### Dashboard Endpoints
| Method | Path | Description |
|--------|------|-------------|
| GET | /api/dashboard/results | Get test history |
| GET | /api/dashboard/latest | Get latest result |
| GET | /api/dashboard/stats | Get summary stats |

### Career Endpoints
| Method | Path | Description |
|--------|------|-------------|
| GET | /api/career/roadmap/ai-robotics | AI/Robotics roadmap data |

---

## 🗄️ Database Schema

### User
```json
{
  "name": "Arjun Kumar",
  "email": "arjun@example.com",
  "password": "<bcrypt hashed>",
  "standard": "10th",
  "school": "GHSS Chennai",
  "district": "Chennai",
  "state": "Tamil Nadu",
  "createdAt": "2024-01-01T00:00:00Z"
}
```

### TestResult
```json
{
  "userId": "<ObjectId>",
  "answers": [{ "questionId": 1, "selectedOption": "Maths & Physics", "category": "science" }],
  "scores": { "science": 7, "commerce": 1, "arts": 1, "vocational": 1 },
  "suggestedStream": "Science Stream",
  "subFields": ["AI & Machine Learning", "Robotics", "Data Science"],
  "primaryCareer": "AI & Machine Learning",
  "confidenceScore": 70,
  "roadmap": { "school": [...], "college": [...], "advanced": [...] },
  "skillsRequired": ["Python", "Mathematics", ...],
  "courses": [{ "name": "B.Tech CSE", "duration": "4 years", "type": "Degree" }],
  "isLatest": true,
  "takenAt": "2024-01-01T00:00:00Z"
}
```

---

## 🧠 AI Career Engine Logic

The AI engine in `backend/routes/test.js` uses **weighted category scoring**:

1. Each answer has a `category` tag (science / commerce / arts / vocational)
2. All answers are tallied to produce scores per stream
3. The top-scoring stream is recommended
4. **Confidence %** = `topScore / totalAnswers × 100`
5. Sub-fields and roadmap are fetched from the `careerData` database object
6. Full career details (courses, skills, salary, roadmap) are returned

---

## 📄 Pages

| Page | Description |
|------|-------------|
| 🏠 Home | Hero, features, stream explorer |
| 🔐 Auth | Login & Signup forms |
| 📝 Career Test | 10-question AI assessment with progress |
| 📊 Results | Stream recommendation + roadmap + skills |
| 🤖 AI Careers | Deep dive into AI & Robotics career page |
| 📈 Dashboard | Saved results, stats, progress tracker |

---

## 🛠️ Tech Stack

| Layer | Technology |
|-------|-----------|
| Frontend | Vanilla HTML/CSS/JS (no framework needed) |
| Backend | Node.js + Express.js |
| Database | MongoDB + Mongoose |
| Auth | JWT (JSON Web Tokens) + bcryptjs |
| Styling | CSS Custom Properties + Glassmorphism |
| Fonts | Syne (headings) + DM Sans (body) |
| Deployment | Any Node.js host + MongoDB Atlas |

---

## ✨ Features

- ✅ AI-powered career assessment (10 questions)
- ✅ 4 career streams with detailed sub-fields
- ✅ Personalized roadmap (School → College → Advanced)
- ✅ JWT authentication (Login/Signup)
- ✅ Student dashboard with history
- ✅ Progress tracker
- ✅ Glassmorphism dark theme UI
- ✅ Fully responsive (mobile + desktop)
- ✅ Works offline (AI engine runs client-side too)
- ✅ Deep dive AI & Robotics career page
- ✅ Tamil Nadu-specific college recommendations

---

## 📞 Support

Built with ❤️ for students in Tamil Nadu, India.

---

*StreamSensely — Helping every student find their stream.*
