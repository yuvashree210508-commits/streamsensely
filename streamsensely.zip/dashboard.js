const express = require('express');
const router = express.Router();
const { protect } = require('../middleware/auth');
const TestResult = require('../models/TestResult');

// GET /api/dashboard/results
router.get('/results', protect, async (req, res) => {
  try {
    const results = await TestResult.find({ userId: req.user._id }).sort({ takenAt: -1 }).limit(10);
    res.json({ results });
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
});

// GET /api/dashboard/latest
router.get('/latest', protect, async (req, res) => {
  try {
    const result = await TestResult.findOne({ userId: req.user._id, isLatest: true });
    res.json({ result });
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
});

// GET /api/dashboard/stats
router.get('/stats', protect, async (req, res) => {
  try {
    const totalTests = await TestResult.countDocuments({ userId: req.user._id });
    const latest = await TestResult.findOne({ userId: req.user._id, isLatest: true });
    res.json({ totalTests, hasResult: !!latest, latestStream: latest?.suggestedStream, latestConfidence: latest?.confidenceScore });
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
});

module.exports = router;
